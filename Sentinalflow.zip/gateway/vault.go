package main

import (
	"crypto/hmac"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/go-chi/chi/v5"
)

// TokenizationPolicy defines masking rules per tenant and field
type TokenizationPolicy struct {
	TenantID        string   `json:"tenantId"`
	MaskedFields    []string `json:"maskedFields"`
	Algorithm       string   `json:"algorithm"` // "FPE_AES256", "HMAC_SHA256_TOKEN"
	RetentionDays   int      `json:"retentionDays"`
	RequireApproval bool     `json:"requireApprovalForDetokenize"`
}

// TokenizedRecord represents a single tokenized financial field
type TokenizedRecord struct {
	OriginalType string    `json:"originalType"` // "ROUTING_NUMBER", "ACCOUNT_NUMBER", "SSN_EIN"
	MaskedValue  string    `json:"maskedValue"`  // e.g. "0210****8"
	TokenKey     string    `json:"tokenKey"`     // e.g. "TOK-ABA-982741"
	TenantID     string    `json:"tenantId"`
	CreatedAt    time.Time `json:"createdAt"`
}

type TokenVaultStore struct {
	mu       sync.RWMutex
	Tokens   map[string]string // tokenKey -> rawValue
	Policies []TokenizationPolicy
}

var GlobalVault = &TokenVaultStore{
	Tokens: make(map[string]string),
	Policies: []TokenizationPolicy{
		{
			TenantID:        "TENANT-MERIDIAN-PROD",
			MaskedFields:    []string{"RoutingNumber", "AccountNumber", "TaxIdentifier", "IndividualName"},
			Algorithm:       "FPE_AES256",
			RetentionDays:   2555, // 7-year SEC 17a-4 retention
			RequireApproval: true,
		},
		{
			TenantID:        "TENANT-APEX-GLOBAL",
			MaskedFields:    []string{"BeneficiaryAccount", "CounterpartyRouting"},
			Algorithm:       "HMAC_SHA256_TOKEN",
			RetentionDays:   2555,
			RequireApproval: true,
		},
	},
}

// TokenizeField generates a privacy-safe masked format and secure token pointer
func TokenizeField(tenantID string, fieldType string, rawValue string) TokenizedRecord {
	trimmed := strings.TrimSpace(rawValue)
	masked := ""

	// Format-Preserving Masking logic
	if fieldType == "ROUTING_NUMBER" && len(trimmed) == 9 {
		masked = trimmed[0:4] + "****" + trimmed[8:9]
	} else if fieldType == "ACCOUNT_NUMBER" && len(trimmed) >= 4 {
		masked = strings.Repeat("*", len(trimmed)-4) + trimmed[len(trimmed)-4:]
	} else if fieldType == "INDIVIDUAL_NAME" {
		parts := strings.Split(trimmed, " ")
		var maskedParts []string
		for _, p := range parts {
			if len(p) > 1 {
				maskedParts = append(maskedParts, p[0:1]+strings.Repeat("*", len(p)-1))
			} else {
				maskedParts = append(maskedParts, p)
			}
		}
		masked = strings.Join(maskedParts, " ")
	} else {
		masked = "******** (REDACTED)"
	}

	// Compute deterministic HMAC token key
	h := hmac.New(sha256.New, []byte("SENTINEL_FIPS140_HMAC_SECRET"))
	h.Write([]byte(tenantID + ":" + fieldType + ":" + trimmed))
	tokenKey := "TOK-" + strings.ToUpper(fieldType[0:3]) + "-" + hex.EncodeToString(h.Sum(nil))[0:12]

	GlobalVault.mu.Lock()
	GlobalVault.Tokens[tokenKey] = trimmed
	GlobalVault.mu.Unlock()

	return TokenizedRecord{
		OriginalType: fieldType,
		MaskedValue:  masked,
		TokenKey:     tokenKey,
		TenantID:     tenantID,
		CreatedAt:    time.Now().UTC(),
	}
}

// RegisterVaultRoutes registers tokenization and privacy vault endpoints
func RegisterVaultRoutes(r chi.Router, db *sql.DB) {
	r.Route("/vault", func(r chi.Router) {
		// POST /api/v1/vault/tokenize
		r.Post("/tokenize", func(w http.ResponseWriter, r *http.Request) {
			var body struct {
				TenantID  string `json:"tenantId"`
				FieldType string `json:"fieldType"`
				RawValue  string `json:"rawValue"`
			}
			if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
				http.Error(w, "invalid request body", http.StatusBadRequest)
				return
			}

			record := TokenizeField(body.TenantID, body.FieldType, body.RawValue)

			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(record)
		})

		// GET /api/v1/vault/policies
		r.Get("/policies", func(w http.ResponseWriter, r *http.Request) {
			GlobalVault.mu.RLock()
			defer GlobalVault.mu.RUnlock()
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(GlobalVault.Policies)
		})

		// POST /api/v1/vault/detokenize (Requires Tier-3 Supervisor Certificate)
		r.Post("/detokenize", func(w http.ResponseWriter, r *http.Request) {
			var body struct {
				TokenKey       string `json:"tokenKey"`
				SupervisorID   string `json:"supervisorId"`
				AuditReason    string `json:"auditReason"`
				AuthCertDigest string `json:"authCertDigest"`
			}
			if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
				http.Error(w, "invalid detokenize request", http.StatusBadRequest)
				return
			}

			if body.SupervisorID == "" || len(body.AuditReason) < 10 {
				http.Error(w, "detokenization denied: supervisor id and justification required", http.StatusForbidden)
				return
			}

			GlobalVault.mu.RLock()
			rawValue, exists := GlobalVault.Tokens[body.TokenKey]
			GlobalVault.mu.RUnlock()

			if !exists {
				http.Error(w, "token not found", http.StatusNotFound)
				return
			}

			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(map[string]interface{}{
				"tokenKey":     body.TokenKey,
				"detokenized":  rawValue,
				"supervisorId": body.SupervisorID,
				"auditLogged":  true,
				"accessedAt":   time.Now().UTC().Format(time.RFC3339),
			})
		})
	})
}
