package main

import (
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"time"
)

type AuditEvent struct {
	ID           int64                  `json:"id"`
	EventType    string                 `json:"eventType"`
	Actor        string                 `json:"actor"`
	Payload      map[string]interface{} `json:"payload"`
	PreviousHash string                 `json:"previousHash"`
	CurrentHash  string                 `json:"currentHash"`
	CreatedAt    string                 `json:"createdAt"`
}

type LedgerSummary struct {
	TotalEvents   int          `json:"totalEvents"`
	IsChainValid  bool         `json:"isChainValid"`
	LastEventHash string       `json:"lastEventHash"`
	Events        []AuditEvent `json:"events"`
}

// AppendAuditEvent inserts a new event into audit_events, computing the SHA-256 hash chained from the last event.
func AppendAuditEvent(db *sql.DB, eventType string, actor string, payload map[string]interface{}) (*AuditEvent, error) {
	// Find last event's hash
	var lastHash string
	row := db.QueryRow("SELECT current_hash FROM audit_events ORDER BY id DESC LIMIT 1")
	err := row.Scan(&lastHash)
	if err == sql.ErrNoRows {
		// Genesis block
		lastHash = "0000000000000000000000000000000000000000000000000000000000000000"
	} else if err != nil {
		return nil, fmt.Errorf("failed to query last audit hash: %w", err)
	}

	payloadBytes, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal payload: %w", err)
	}

	now := time.Now().UTC().Format(time.RFC3339)
	hashInput := fmt.Sprintf("%s|%s|%s|%s|%s", lastHash, eventType, actor, string(payloadBytes), now)
	hasher := sha256.New()
	hasher.Write([]byte(hashInput))
	currentHash := hex.EncodeToString(hasher.Sum(nil))

	res, err := db.Exec(`
		INSERT INTO audit_events (event_type, actor, payload, previous_hash, current_hash, created_at)
		VALUES (?, ?, ?, ?, ?, ?)
	`, eventType, actor, string(payloadBytes), lastHash, currentHash, now)
	if err != nil {
		return nil, fmt.Errorf("failed to insert audit event: %w", err)
	}

	id, _ := res.LastInsertId()
	return &AuditEvent{
		ID:           id,
		EventType:    eventType,
		Actor:        actor,
		Payload:      payload,
		PreviousHash: lastHash,
		CurrentHash:  currentHash,
		CreatedAt:    now,
	}, nil
}

// GetLedger retrieves the audit events and verifies hash chain integrity.
func GetLedger(db *sql.DB) (*LedgerSummary, error) {
	rows, err := db.Query("SELECT id, event_type, actor, payload, previous_hash, current_hash, created_at FROM audit_events ORDER BY id ASC")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	events := make([]AuditEvent, 0)
	isValid := true
	expectedPrev := "0000000000000000000000000000000000000000000000000000000000000000"
	lastHash := expectedPrev

	for rows.Next() {
		var ev AuditEvent
		var rawPayload string
		if err := rows.Scan(&ev.ID, &ev.EventType, &ev.Actor, &rawPayload, &ev.PreviousHash, &ev.CurrentHash, &ev.CreatedAt); err != nil {
			return nil, err
		}
		_ = json.Unmarshal([]byte(rawPayload), &ev.Payload)

		if ev.PreviousHash != expectedPrev {
			isValid = false
		}
		expectedPrev = ev.CurrentHash
		lastHash = ev.CurrentHash
		events = append(events, ev)
	}

	return &LedgerSummary{
		TotalEvents:   len(events),
		IsChainValid:  isValid,
		LastEventHash: lastHash,
		Events:        events,
	}, nil
}
