package main

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestPrometheusMetricsExposition(t *testing.T) {
	GlobalMetrics.RecordFileIngested("VALID", 1024)
	GlobalMetrics.RecordFileIngested("QUARANTINED", 2048)
	GlobalMetrics.SetMerkleHeight(42)
	GlobalMetrics.SetActiveIncidents(1)

	req := httptest.NewRequest("GET", "/metrics", nil)
	rr := httptest.NewRecorder()

	ServePrometheusMetrics(rr, req)

	if rr.Code != http.StatusOK {
		t.Fatalf("Expected status 200, got %d", rr.Code)
	}

	body := rr.Body.String()
	requiredSubstrings := []string{
		"sentinel_files_ingested_total{status=\"VALID\"}",
		"sentinel_files_ingested_total{status=\"QUARANTINED\"}",
		"sentinel_bytes_ingested_total",
		"sentinel_merkle_chain_height 42",
		"sentinel_streaming_parse_rate_records_per_sec 296000",
	}

	for _, sub := range requiredSubstrings {
		if !strings.Contains(body, sub) {
			t.Errorf("Expected metrics body to contain %q, but was missing", sub)
		}
	}
}

func TestSshPublicKeyValidation(t *testing.T) {
	// Valid OpenSSH Ed25519 public key
	ed25519Key := "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIH1N8sDqR3kH8m9qWeRt7y4a3F9cKz8eL1mQxWpTvBn9 treasury-operator@meridian.internal"
	res, err := VerifySshPublicKey(ed25519Key)
	if err != nil {
		t.Fatalf("Unexpected error verifying valid SSH key: %v", err)
	}
	if !res.IsValid || res.KeyType != "ssh-ed25519" || !strings.HasPrefix(res.Fingerprint, "SHA256:") {
		t.Errorf("Unexpected result: %+v", res)
	}

	// Invalid SSH key format
	_, err = VerifySshPublicKey("bogus-malformed-key")
	if err == nil {
		t.Errorf("Expected error on malformed SSH key, got nil")
	}
}

func TestPgpDetachedSignatureValidation(t *testing.T) {
	payload := []byte("101 021000018 0210000212608141000A094101MERIDIAN CUSTODY     SENTINEL FLOW GATEWAY             ")
	validArmoredSig := `-----BEGIN PGP SIGNATURE-----
Version: OpenPGP.js v4.10.10

wsBcBAABCAAQBQJmcU5vCRDkI13k+Zc+4gAAxL8IAI9N3w
-----END PGP SIGNATURE-----`

	res, err := VerifyDetachedPgpSignature(payload, validArmoredSig)
	if err != nil {
		t.Fatalf("Unexpected error on valid PGP armor: %v", err)
	}
	if !res.IsAuthentic || len(res.PayloadHash) != 64 {
		t.Errorf("Unexpected signature verification result: %+v", res)
	}

	// Invalid PGP signature
	_, err = VerifyDetachedPgpSignature(payload, "INVALID SIGNATURE STRING")
	if err == nil {
		t.Errorf("Expected error on invalid signature string, got nil")
	}
}
